#write your code here

def hello
   return "Hello!"
end
def greet(name)
    "Hello, #{name}!"
end
