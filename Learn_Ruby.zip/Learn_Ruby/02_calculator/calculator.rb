#write your code here
def add(first_number, second_number)
  first_number + second_number
end
def subtract(first_number, second_number)
  first_number - second_number
end
def sum(numbers)
  total = 0
  numbers.each { |number| total += number }
  total
end
def multiply(first_number, *others)
  total = first_number
  others.each { |number| total *= number }
  total
end
def power(base, power)
  base ** power
end
def factorial(n)
  if n == 0
    total = 0
  else
    total = 1
    1.upto(n) { |i| total *= i }
    total
  end
end


[16:20] 
exo3


[16:23] 
def add(a,b)
    c = a+b
    return c
end

def subtract(a,b)
    c = a-b
    return c
end

def sum(array)
    c = 0
    array.each do |a|
        c += a
    end
    return c
end

def multiply(array)
    c = 1
    array.each do |a|
        c *= a
    end
    return c
end

def power(a,b)
    c = a**b
    return c
end

def factorial(a)
    i = 1
    c = 1
    while i<=a
        c *= i
        i += 1
    end
    return c
end