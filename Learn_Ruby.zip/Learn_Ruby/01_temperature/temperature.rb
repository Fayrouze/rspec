#write your code here
def ftoc(temperature)
 temperature = (temperature - 32.0) * (5.0/9.0)
end

def ctof(temperature)
 temperature = (temperature * (9.0 / 5.0)) + 32
end
